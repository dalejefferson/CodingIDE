
# drawer

  touch-enabled slide-in drawer ui component

## Installation

  Install with [component(1)](http://component.io):

    $ component install component/drawer

## API

TODO: custom element

## License

  MIT
